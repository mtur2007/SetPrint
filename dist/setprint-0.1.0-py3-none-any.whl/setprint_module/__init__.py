# your_module __init__.py
from .setprint import Myint, set_txt,set_txts, set_number,set_numbers, slice_blocks, setprint
